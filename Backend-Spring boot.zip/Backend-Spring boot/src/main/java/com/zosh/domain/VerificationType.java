package com.zosh.domain;

public enum VerificationType {
    MOBILE,
    EMAIL
}
